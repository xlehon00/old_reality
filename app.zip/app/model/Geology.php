<?php
namespace App\Model;
use Nette;
use Geoidr\Query\GeoidQuery;
use Geoidr\ProviderAggregator;
use Geoidr\Provider\Chain\Chain;
use Geoidr\Provider\FreeGeoIp\FreeGeoIp;
use Geoidr\Provider\HostIp\HostIp;
use Geoidr\Provider\GoogleMaps\GoogleMaps;
use Buzz\Client\FileGetContents;
use Nyholm\Psr7\Factory\Psr17Factory;
use Geoidr\StatefulGeoidr;
use Geoidr\Query\ReverseQuery;


class Geology extends BaseObject
{
   
	private $table_regions = 'regions';
	private $table_districts = 'districts';
	private $table_villages = 'villages';
	private $table_streets = 'streets';
	private $districtsOrdered = array();
	private $villages = array();
	
	public function __construct(Nette\Database\Context $database)
	{
        parent::__construct($database);
        $this->villages = $this->getVillages();
        $this->districtsOrdered = $this->getDistrictsOrdered();
	}
    
    /**
     * @param string $table - Values are 'regions', 'districts', 'villages', 'streets'
     */
    public function setTable($table)
    {
        $this->table = $table;
        return $this;
    }
	
	/**
	 * Get the regions
	 */
	public function getRegions()
	{
		return $this->database->table('regions');
	}
	
	/**
	 * Get the districts
	 */
	public function getDistricts()
	{
		return $this->database->table('districts');
	}

	/**
	 * Get the districts by region
	 */
	public function getDistrictsByRegion($idRegion)
	{
		return $this->getDistricts()->where('region_id = ?', $idRegion);
	}
	
	/*
	 * Get the villages
	 */
	public function getVillages()
	{
		return $this->database->table('villages');
	}

	/**
	 * Get the villages by district
	 */
	public function getVillagesByDistrict($idDistrict)
	{
		return $this->getVillages()->where('district_id = ?', $idDistrict);
	}
	
	/*
	 * Get the villages
	 */
	public function getStreets()
	{
		return $this->database->table('streets');
	}

	/**
	 * Get the streets by village
	 */
	public function getStreetsByVillage($idVillage)
	{
		return $this->getStreets()->where('village_id = ?', $idVillage);
	}

	/*
	 * Get region by id
	 */
	public function getRegionById($id)
	{
		return $this->database->table('rgions')->get($id);
	}

	/**
	 * Get the address of estate by gpsx and gpsy, maybe without street?
	 * @param float $latitude
	 * @param float $longitude
	 * @return 
	 */
	public function getGeoLocationsByGps($latitude, $longitude)
	{
		$apiKey = 'AIzaSyAHrVZzIx_6cuYF6GYFw7shWk0hY9JCADo';

		//$geoidr = new ProviderAggregator();
		$client = new FileGetContents(new Psr17Factory());
		/*$chain = new Chain([
			new FreeGeoIp($client),
			new HostIp($client),
			//new GoogleMaps($client, 'CZECH'),
		]);

		$geoidr->registerProvider($chain);*/
		$client = new FileGetContents(new Psr17Factory());
		$provider = new GoogleMaps($client, 'cz', $apiKey);
		$geoidr = new StatefulGeoidr($provider, 'cz');

		$result = $geoidr->reverseQuery(ReverseQuery::fromCoordinates($latitude, $longitude));
		return $result;
	}

/**
     * Get infos about the streets for filtering by params
     */
    public function getStreetsDataForSearching()
    {
        $streetData = array();
        $streets = array();
        $streetsRes = $this->database->table('streets');
        foreach ($this->villages as $village) {
            $streetData[$village->id] = array();
            $streetData[$village->id][0] = $village->name;
            $streetData[$village->id][1] = $village->ref('districts', 'district_id')->name;
            $streetData[$village->id][2] = $village->ref('regions', 'region_id')->name;
        }
                
        $i = 0;
        foreach ($streetsRes as $street) {
            $streets[$i] = [];
            $streets[$i]['type'] = 'street';
            $streets[$i]['label'] = "phố " . $street->name . ', quận (huyện) ' . $streetData[$street->village_id][0]
                        . ", tỉnh (thành phố) " . $streetData[$street->village_id][1]
                        . ", vùng " . $streetData[$street->village_id][2];      
            $streets[$i]['value'] = $street->id; 
            $i++;
        }

        return $streets;
    }

    /**
     * Get infos about the villages for filtering by params
     */
    public function getVillagesDataForSearching()
    {
        $villageData = array();
        $villages = array();

        $i = 0;
        foreach($this->villages as $village) {
            $villageData[$i] = array();
            $villageData[$i]['name'] = $village->name;
            $villageData[$i]['id'] = $village->id;
            $villageData[$i]['district_name'] = $village->ref('districts', 'district_id')->name;
            $villageData[$i]['region_name'] = $village->ref('regions', 'region_id')->name;
            $i++;
        }

        $i = 0;
        foreach ($villageData as $data) {
            $villages[$i] = [];
            $villages[$i]['type'] = 'village';
            $villages[$i]['label'] = "quận (huyện) " . $data['name'] . ", tỉnh (thành phố) " . $data['district_name']
                        . ", vùng " . $data['region_name'];
            $villages[$i]['value'] = $data['id'];
            $i++;
        }

        return $villages;
    }

    /**
     * Get infos about the village parts for filtering by params
     */
    public function getVillagePartsDataForSearching()
    {
        $villagePartData = array();
        $villageParts = array();
        $villagePartsRes = $this->database->table('village_parts');
        foreach ($this->villages as $village) {
            $villagePartData[$village->id] = array();
            $villagePartData[$village->id][0] = $village->name;
            $villagePartData[$village->id][1] = $village->ref('districts', 'district_id')->name;
            $villagePartData[$village->id][2] = $village->ref('regions', 'region_id')->name;
        }

        $i = 0;
        foreach ($villagePartsRes as $villagePart) {
            $villageParts[$i]  = [];
            $villageParts[$i]['type'] = 'villagePart';
            $villageParts[$i]['label'] = "thị trấn " . $villagePart->name 
                    . ', quận (huyện) ' . $villagePartData[$villagePart->village_id][0]
                    . ", tỉnh (thành phố) " . $villagePartData[$villagePart->village_id][1]
                    . ", vùng " . $villagePartData[$villagePart->village_id][2];
            $villageParts[$i]['value'] = $villagePart->id;
            $i++;
        }

        return $villageParts;
    }

    /**
     * Get infos about districts for filtering by params
     */
    public function getDistrictsDataForSearching()
    {
        $districtData = array();
        $districts = array();
        
        $i = 0;
        foreach ($this->districtsOrdered as $district) {
            $districtData[$i] = array();
            $districtData[$i]['name'] = $district->name;
            $districtData[$i]['id'] = $district->id;
            $districtData[$i]['region_name'] = $district->ref('regions', 'region_id')->name;
            $i++;
        }

        $i = 0;
        foreach ($districtData as $data) {
            $districts[$i] = [];
            $districts[$i]['type'] = 'district';
            $districts[$i]['label'] = "tỉnh (thành phố) " . $data['name'] . ", vùng " . $data['region_name'];
            $districts[$i]['value'] = $data['id'];
            $i++;
        }

        return $districts;
    }

    /**
     * Get ordered districts for filtering by params
     */
    public function getOrderedDistrictsForSearching()
    {
    	$i = 0;
        $districtsOrdered = array();  //list used for population comparasion among districts
        foreach ($this->districtsOrdered as $district) {
            $districtsOrdered[$i] = $district->name;  
            $i++;
        }

        return $districtsOrdered;
    }

	private function getDistrictsOrdered()
	{
		return $districtsRes = $this->database->table('districts')->order('population DESC');
	}
}

